import logging

def test():
    logging.info('Testing function calling.')